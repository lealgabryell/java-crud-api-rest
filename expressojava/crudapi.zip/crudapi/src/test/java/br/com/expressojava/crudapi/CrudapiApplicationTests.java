package br.com.expressojava.crudapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
